/**
 * ScamSentry Extension Popup Logic
 * 
 * Synchronizes with the background service worker to display 
 * real-time forensic data for the current active tab.
 */

document.addEventListener('DOMContentLoaded', async () => {
  const loadingEl = document.getElementById('loading');
  const mainUiEl = document.getElementById('main-ui');
  const urlEl = document.getElementById('current-url');
  const badgeEl = document.getElementById('risk-badge');
  const scoreBarEl = document.getElementById('score-bar');
  const scoreValEl = document.getElementById('score-val');
  
  const linksScannedEl = document.getElementById('links-scanned');
  const threatsBlockedEl = document.getElementById('threats-blocked');
  const dashboardBtn = document.getElementById('view-dashboard');

  // 1. Get current active tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url) {
    loadingEl.textContent = 'No active page detected.';
    return;
  }

  const currentUrl = new URL(tab.url);
  urlEl.textContent = currentUrl.hostname + currentUrl.pathname;

  // 2. Request status from background
  chrome.runtime.sendMessage({ type: 'CHECK_URL', url: tab.url }, (result) => {
    loadingEl.style.display = 'none';
    mainUiEl.style.display = 'block';

    if (result && result.status !== 'error') {
      const threatScore = result.score || 0;
      const isMalicious = result.status === 'malicious' || threatScore > 70;
      const isSuspicious = !isMalicious && (result.status === 'suspicious' || threatScore > 20);
      
      if (isMalicious) {
        badgeEl.textContent = 'Malicious';
        badgeEl.className = 'risk-badge malicious';
      } else if (isSuspicious) {
        badgeEl.textContent = 'Suspicious';
        badgeEl.className = 'risk-badge suspicious';
      } else {
        badgeEl.textContent = 'Safe';
        badgeEl.className = 'risk-badge safe';
      }
      
      // Update score display - display true Trust Score (100 - threat penalty)
      const trustScore = Math.max(0, 100 - threatScore);
      scoreBarEl.style.width = `${trustScore}%`;
      scoreValEl.textContent = `${trustScore}%`;
      
      if (isMalicious) {
        scoreBarEl.style.backgroundColor = '#FF4D4D';
        scoreValEl.style.color = '#FF4D4D';
      } else if (isSuspicious) {
        scoreBarEl.style.backgroundColor = '#F59E0B';
        scoreValEl.style.color = '#F59E0B';
      } else {
        scoreBarEl.style.backgroundColor = ''; // Reverts to CSS primary orange
        scoreValEl.style.color = '';
      }
    }
  });

  // 3. Load global stats from storage
  chrome.storage.local.get(['stats_links', 'stats_blocked'], (data) => {
    linksScannedEl.textContent = (data.stats_links || 0).toLocaleString();
    threatsBlockedEl.textContent = (data.stats_blocked || 0).toLocaleString();
  });

  // 4. Action handlers
  dashboardBtn.addEventListener('click', () => {
    chrome.storage.local.get('dashboard_url', (settings) => {
      const targetUrl = settings.dashboard_url || 'https://scamsentry.vercel.app/dashboard';
      chrome.tabs.create({ url: targetUrl });
    });
  });
});
